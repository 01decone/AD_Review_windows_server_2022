#Requires -Version 5.1
<#
.SYNOPSIS
    READ-ONLY audit of a Windows Server 2022 host against the CIS Microsoft Windows Server 2022 Benchmark v5.1.0
    (all 408 recommendations: L1, L2 and Next Generation profiles, Domain Controller and Member Server).

.DESCRIPTION
    For every recommendation the report contains: Control ID, Title, Profile Level, Applies To, Assessment Status,
    RESULT (Compliant / Non-Compliant / Not Applicable / Manual Review / Error), Expected Value, Actual Value,
    Evidence (raw data read from the host), Evidence Command (how to reproduce it manually), Description,
    Rationale, Impact, Audit Procedure, Remediation, Default Value, References and CIS Controls mapping.

    SAFETY - this tool performs NO write, update or delete on the audited system:
      * Registry  : RegistryKey.OpenSubKey(path, writable:$false) - read-only handles only.
      * User rights / account domain : LsaOpenPolicy with POLICY_VIEW_LOCAL_INFORMATION | POLICY_LOOKUP_NAMES (query only).
      * Password policy flags : SamConnect / SamOpenDomain with read-only access masks + SamQueryInformationDomain.
      * Password / lockout values : NetUserModalsGet (query only).
      * Audit policy : 'auditpol.exe /get' (query only).   * Accounts : CIM query + SID translation.
      * No secedit export, no temp files, no Add-Type compilation (P/Invoke is defined in memory).
    The ONLY files written are the NEW report files in -OutputPath (existing files are never overwritten).

.PARAMETER OutputPath   Folder for the reports (created if missing). Default: .\Reports next to this script.
.PARAMETER Role         Auto (detect via Win32_ComputerSystem.DomainRole), DC or MS.
.PARAMETER Level        L1 = Level 1 only; L2 = Level 1 + Level 2; All = L1 + L2 + Next Generation (default).
.PARAMETER NoXlsx       Skip the .xlsx report (CSV and HTML are always produced).

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File .\Invoke-CISWS2022Audit.ps1
.EXAMPLE
    .\Invoke-CISWS2022Audit.ps1 -Role MS -Level L1 -OutputPath D:\Audit
.NOTES
    Run from an elevated PowerShell (Run as Administrator). Windows PowerShell 5.1 or PowerShell 7+.
#>
[CmdletBinding()]
param(
    [string]$OutputPath = (Join-Path $PSScriptRoot 'Reports'),
    [ValidateSet('Auto', 'DC', 'MS')][string]$Role = 'Auto',
    [ValidateSet('L1', 'L2', 'All')][string]$Level = 'All',
    [string]$ControlsFile = (Join-Path $PSScriptRoot 'Data\CIS_WS2022_v5.1.0_Controls.json'),
    [switch]$NoXlsx
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ToolVersion = '1.2.0'
$moduleNames = 'Native', 'Collectors', 'RegistryEval', 'Engine', 'Severity', 'Xlsx', 'Report'
# ---- integrity check: refuse to run with a mix of old and new files (e.g. zip extracted over an older copy) ----
$stale = @()
foreach ($m in $moduleNames) {
    $mp = Join-Path $PSScriptRoot "Modules\CISAudit.$m.psm1"
    if (-not (Test-Path -LiteralPath $mp)) { $stale += "missing Modules\CISAudit.$m.psm1"; continue }
    if (-not (Select-String -LiteralPath $mp -SimpleMatch "# CISAudit-Version: $ToolVersion" -Quiet)) { $stale += "Modules\CISAudit.$m.psm1 is from another version" }
}
if ($stale.Count) {
    throw ("Tool files are incomplete or from different versions (expected $ToolVersion):`n  " + ($stale -join "`n  ") +
        "`nExtract CIS_WS2022_Audit.zip into a NEW, EMPTY folder and run Invoke-CISWS2022Audit.ps1 from there.")
}
foreach ($m in $moduleNames) {
    Import-Module (Join-Path $PSScriptRoot "Modules\CISAudit.$m.psm1") -Force -Global -DisableNameChecking
}

function Write-CISStep { param([string]$Message) Write-Host ('[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Message) -ForegroundColor Cyan }

# ---------- 0. Output-folder guard: reports may never be written into OS / program folders ----------
$OutputPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
$protected = @($env:SystemRoot, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData) | Where-Object { $_ } |
    ForEach-Object { [System.IO.Path]::GetFullPath($_).TrimEnd('\') + '\' }
foreach ($pp in $protected) {
    if (($OutputPath.TrimEnd('\') + '\').StartsWith($pp, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "OutputPath '$OutputPath' is inside a protected system folder ($pp). Choose another folder, e.g. D:\CIS_Reports."
    }
}

# ---------- 1. Load benchmark definitions ----------
if (-not (Test-Path -LiteralPath $ControlsFile)) { throw "Controls file not found: $ControlsFile" }
$data = [System.IO.File]::ReadAllText($ControlsFile, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
$benchmark = '{0} {1}' -f $data.meta.benchmark, $data.meta.version
if (-not ($data.meta.PSObject.Properties.Name -contains 'toolVersion') -or $data.meta.toolVersion -ne $ToolVersion) {
    throw "Data file '$ControlsFile' is not version $ToolVersion (no severity data). Extract the new zip into a NEW, EMPTY folder."
}
Write-CISStep "CIS audit tool v$ToolVersion (with severity rating) - loaded $($data.controls.Count) recommendations - $benchmark"

# ---------- 2. Host information ----------
$sys = Get-CISSystemInfo
if (-not $sys.IsAdmin) { Write-Warning 'Not running elevated. User rights, audit policy and SAM checks will report Error. Re-run as Administrator.' }
if ($sys.OSCaption -notmatch 'Server 2022') { Write-Warning "OS is '$($sys.OSCaption)'. This benchmark targets Windows Server 2022; results may not be meaningful." }
$effectiveRole = if ($Role -eq 'Auto') { $sys.DetectedRole } else { $Role }
$levels = switch ($Level) { 'L1' { @('L1') } 'L2' { @('L1', 'L2') } default { @('L1', 'L2', 'NG') } }
$sys | Add-Member -NotePropertyName EvaluatedRole -NotePropertyValue $(if ($effectiveRole -eq 'DC') { 'Domain Controller' } else { 'Member Server' })
$sys | Add-Member -NotePropertyName ToolVersion -NotePropertyValue $ToolVersion
$sys | Add-Member -NotePropertyName ProfilesSelected -NotePropertyValue ($levels -join ', ')
Write-CISStep "Host $($sys.ComputerName) | $($sys.OSCaption) | role: $($sys.EvaluatedRole) | profiles: $($sys.ProfilesSelected)"

# ---------- 3. Collect data (read-only) ----------
$ctx = @{
    Role = $effectiveRole; Levels = $levels; LevelParam = $Level; ComputerName = $sys.ComputerName; AuditTime = $sys.AuditTime
    UserSids = @(); UserRights = @{}; UserRightsError = $null; AuditPolicy = @{}; AuditPolicyError = $null; AuditPolicyRaw = ''
    AccountPolicy = $null; AccountPolicyError = $null; Accounts = @{}; AccountsError = $null; Meta = @{}
}
Write-CISStep 'Reading loaded user hives (HKEY_USERS)...'
$ctx.UserSids = @(Get-CISLoadedUserSid)

Write-CISStep 'Reading user rights assignments (LSA, read-only)...'
$rights = @($data.controls | Where-Object { $_.check.type -eq 'userright' } | ForEach-Object { $_.check.right } | Select-Object -Unique)
try { $ctx.UserRights = Get-CISUserRightAssignment -Right $rights } catch { $ctx.UserRightsError = $_.Exception.Message; Write-Warning $ctx.UserRightsError }

Write-CISStep 'Reading advanced audit policy (auditpol /get)...'
try { $ap = Get-CISAuditPolicy; $ctx.AuditPolicy = $ap.Map; $ctx.AuditPolicyRaw = $ap.Raw } catch { $ctx.AuditPolicyError = $_.Exception.Message; Write-Warning $ctx.AuditPolicyError }

Write-CISStep 'Reading password / lockout policy (NetUserModalsGet + SAM, read-only)...'
try { $ctx.AccountPolicy = Get-CISAccountPolicy } catch { $ctx.AccountPolicyError = $_.Exception.Message; Write-Warning $ctx.AccountPolicyError }

Write-CISStep 'Reading built-in Administrator / Guest accounts...'
try {
    $domSid = (Get-CISAccountDomainSid).Value
    $ctx.Accounts = Get-CISBuiltinAccount -DomainSid $domSid -SkipState:($effectiveRole -eq 'DC')
}
catch { $ctx.AccountsError = $_.Exception.Message; Write-Warning $ctx.AccountsError }

Write-CISStep 'Reading context facts for severity rating (read-only)...'
$facts = @{}
try { $facts = Get-CISSeverityFact -Context $ctx -SystemInfo $sys } catch { Write-Warning "Severity facts: $($_.Exception.Message)" }

# ---------- 4. Evaluate ----------
$results = New-Object System.Collections.Generic.List[object]
$i = 0; $total = $data.controls.Count
foreach ($c in $data.controls) {
    $i++
    try { Write-Progress -Activity 'CIS Windows Server 2022 audit' -Status "$($c.id)" -PercentComplete ([int](100 * $i / $total)) } catch { $null = $_ }
    $results.Add((Invoke-CISControl -Control $c -Context $ctx))
}
try { Write-Progress -Activity 'CIS Windows Server 2022 audit' -Completed } catch { $null = $_ }
Set-CISFindingSeverity -Rows $results.ToArray() -Controls @($data.controls) -Context $ctx -Facts $facts
$summary = Get-CISSummary -Results $results.ToArray()

# ---------- 5. Reports (new files in OutputPath only) ----------
if (-not (Test-Path -LiteralPath $OutputPath)) { [void](New-Item -ItemType Directory -Path $OutputPath) }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$baseName = 'CIS_WS2022_v5.1.0_{0}_{1}' -f $sys.ComputerName, $stamp
$csvPath = Join-Path $OutputPath "$baseName.csv"
$htmlPath = Join-Path $OutputPath "$baseName.html"
$xlsxPath = Join-Path $OutputPath "$baseName.xlsx"
$evDir = Join-Path $OutputPath "$baseName`_Evidence"
[void](New-Item -ItemType Directory -Path $evDir)

Export-CISCsv -Path $csvPath -Results $results.ToArray()
Export-CISHtml -Path $htmlPath -Results $results.ToArray() -SystemInfo $sys -Summary $summary -Benchmark $benchmark
if (-not $NoXlsx) {
    try { Export-CISXlsxReport -Path $xlsxPath -Results $results.ToArray() -SystemInfo $sys -Summary $summary }
    catch { Write-Warning "XLSX export failed ($($_.Exception.Message)). CSV/HTML are available."; $xlsxPath = $null }
}

# Raw evidence snapshot (what the tool actually read)
Save-CISEvidenceFile -Folder $evDir -Name 'system_info.txt' -Content ($sys | Format-List | Out-String -Width 300)
Save-CISEvidenceFile -Folder $evDir -Name 'auditpol_all.csv' -Content $(if ($ctx.AuditPolicyError) { "ERROR: $($ctx.AuditPolicyError)" } else { $ctx.AuditPolicyRaw })
$ur = foreach ($k in ($ctx.UserRights.Keys | Sort-Object)) {
    '{0} = {1}' -f $k, $(if ($ctx.UserRights[$k].Count) { ($ctx.UserRights[$k] | ForEach-Object { '{0} ({1})' -f (Resolve-CISSidName -Sid $_), $_ }) -join '; ' } else { 'No One' })
}
Save-CISEvidenceFile -Folder $evDir -Name 'user_rights.txt' -Content $(if ($ctx.UserRightsError) { "ERROR: $($ctx.UserRightsError)" } else { $ur -join [Environment]::NewLine })
Save-CISEvidenceFile -Folder $evDir -Name 'account_policy.txt' -Content $(if ($ctx.AccountPolicy) { $ctx.AccountPolicy | Format-List | Out-String -Width 300 } else { "ERROR: $($ctx.AccountPolicyError)" })
Save-CISEvidenceFile -Folder $evDir -Name 'net_accounts.txt' -Content ((& "$env:SystemRoot\System32\net.exe" accounts 2>&1) -join [Environment]::NewLine)
Save-CISEvidenceFile -Folder $evDir -Name 'builtin_accounts.txt' -Content $(if ($ctx.AccountsError) { "ERROR: $($ctx.AccountsError)" } else { $ctx.Accounts.Values | Format-List | Out-String -Width 300 })
Save-CISEvidenceFile -Folder $evDir -Name 'severity_context_facts.txt' -Content (($facts.Keys | Sort-Object | ForEach-Object { '{0} = {1}' -f $_, $facts[$_] }) -join [Environment]::NewLine)
Save-CISEvidenceFile -Folder $evDir -Name 'loaded_user_hives.txt' -Content (($ctx.UserSids | ForEach-Object { '{0} = {1}' -f $_, (Resolve-CISSidName -Sid $_) }) -join [Environment]::NewLine)

# ---------- 6. Console summary ----------
Write-Host ''
Write-Host "==== $benchmark - $($sys.ComputerName) ($($sys.EvaluatedRole)) ====" -ForegroundColor White
foreach ($k in $summary.Counts.Keys) {
    $color = switch ($k) { 'Compliant' { 'Green' } 'Non-Compliant' { 'Red' } 'Not Applicable' { 'Gray' } default { 'Yellow' } }
    Write-Host ('{0,-16}: {1}' -f $k, $summary.Counts[$k]) -ForegroundColor $color
}
Write-Host ('Compliance score: {0}%  (Compliant / (Compliant + Non-Compliant))' -f $summary.Score)
Write-Host ('Open findings   : ' + (($summary.Severity.Keys | ForEach-Object { '{0}={1}' -f $_, $summary.Severity[$_] }) -join '  '))
Write-Host "CSV      : $csvPath"
Write-Host "HTML     : $htmlPath"
if ($xlsxPath) { Write-Host "XLSX     : $xlsxPath" }
Write-Host "Evidence : $evDir"
