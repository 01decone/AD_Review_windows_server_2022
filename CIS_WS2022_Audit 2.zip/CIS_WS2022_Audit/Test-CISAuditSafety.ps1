#Requires -Version 5.1
<#
.SYNOPSIS
    Static safety verification of the CIS audit tool. Does NOT execute the audit and touches nothing.
.DESCRIPTION
    Parses every .ps1/.psm1 of the tool with the PowerShell parser (AST) and checks:
      1. Every command / cmdlet / executable used is on an explicit allow-list (anything else = FAIL).
      2. External executables are only called with query arguments (auditpol /get, net accounts without switches).
      3. No method call matches a write / delete / modify API (registry, LSA, SAM, NetAPI, file, service, WMI).
      4. Registry keys are only opened with writable = $false; native handles only with read/query access masks.
      5. Marshal.Write* only target buffers the tool allocated itself (process memory, not the system).
      6. Files are only created inside the report folder, as NEW files (CreateNew / -NoClobber).
    Exit code 0 = all checks passed, 1 = at least one finding.
.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File .\Test-CISAuditSafety.ps1
#>
[CmdletBinding()]
param([string]$Path = $PSScriptRoot)
Set-StrictMode -Version Latest

$allowedCommands = @(
    # built-in, read-only / in-memory / console cmdlets
    'Add-Member', 'ConvertFrom-Csv', 'ConvertFrom-Json', 'ForEach-Object', 'Format-List', 'Get-CimInstance', 'Get-Date',
    'Group-Object', 'Import-Module', 'Join-Path', 'New-Object', 'Out-String', 'Select-Object', 'Set-StrictMode', 'Sort-Object',
    'Test-Path', 'Where-Object', 'Select-String', 'Write-Host', 'Write-Progress', 'Write-Warning', 'Export-ModuleMember',
    # report output only (validated below)
    'Export-Csv', 'New-Item', 'Add-Type'
)
$allowedExternal = @{
    'auditpol.exe' = '^\s*/get\s+/category:\*\s+/r\s*$'
    'net.exe'      = '^\s*accounts\s*$'
}
$forbiddenMethods = 'SetValue|CreateSubKey|DeleteSubKey|DeleteValue|DeleteSubKeyTree|SetAccessControl|Flush|' +
    'LsaAdd|LsaRemove|LsaSet|LsaStore|LsaCreate|LsaDelete|SamSet|SamCreate|SamDelete|SamAdd|SamRemove|SamChange|' +
    'NetUserModalsSet|NetUserSet|NetUserAdd|NetUserDel|NetLocalGroup|AuditSet|AdjustTokenPrivileges|' +
    'Delete$|Move$|MoveTo|CopyTo|Encrypt|Decrypt|SetAttributes|SetLastWriteTime|AppendAllText|WriteAllBytes|WriteAllLines|' +
    'InvokeMethod|Invoke$|Start$|Kill|Stop$|Put$|ChangeStartMode|StartService|StopService'
$findings = New-Object System.Collections.Generic.List[string]
$infos = New-Object System.Collections.Generic.List[string]

$files = Get-ChildItem -LiteralPath $Path -Recurse -Include *.ps1, *.psm1 | Where-Object { $_.Name -ne 'Test-CISAuditSafety.ps1' }
$ownFunctions = @()
$asts = @{}
foreach ($f in $files) {
    $tok = $null; $err = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tok, [ref]$err)
    if ($err.Count) { $findings.Add("PARSE ERROR $($f.Name): $($err[0].Message)") }
    $asts[$f.Name] = $ast
    $ownFunctions += @($ast.FindAll({ $args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true) | ForEach-Object { $_.Name })
}

foreach ($name in $asts.Keys) {
    $ast = $asts[$name]
    # ---- 1/2. commands ----
    foreach ($c in $ast.FindAll({ $args[0] -is [System.Management.Automation.Language.CommandAst] }, $true)) {
        $where = '{0}:{1}' -f $name, $c.Extent.StartLineNumber
        $cmd = $c.GetCommandName()
        if ($cmd) {
            if ($ownFunctions -contains $cmd -or $allowedCommands -contains $cmd) { continue }
            $findings.Add("$where command not on allow-list: $cmd"); continue
        }
        $text = $c.Extent.Text
        if ($text -match '^&\s*\$enc\s') { continue }   # local HtmlEncode script block
        $exe = $allowedExternal.Keys | Where-Object { $text -match [regex]::Escape($_) } | Select-Object -First 1
        if (-not $exe) { $findings.Add("$where dynamic / external invocation not allowed: $text"); continue }
        $argsText = ($c.CommandElements | Select-Object -Skip 1 | Where-Object { $_ -isnot [System.Management.Automation.Language.RedirectionAst] } | ForEach-Object { $_.Extent.Text }) -join ' '
        $argsText = ($argsText -replace '2>&1', '').Trim()
        if ($argsText -notmatch $allowedExternal[$exe]) { $findings.Add("$where $exe called with non-query arguments: '$argsText'") }
        else { $infos.Add("$where $exe $argsText  (query only)") }
    }
    # ---- 3/4/5. method calls ----
    foreach ($m in $ast.FindAll({ $args[0] -is [System.Management.Automation.Language.InvokeMemberExpressionAst] }, $true)) {
        $where = '{0}:{1}' -f $name, $m.Extent.StartLineNumber
        $member = $m.Member.Extent.Text.Trim("'", '"')
        if ($member -match "^($forbiddenMethods)") { $findings.Add("$where forbidden method: $($m.Extent.Text)") }
        if ($member -eq 'OpenSubKey') {
            $a = @($m.Arguments)
            if ($a.Count -lt 2 -or $a[1].Extent.Text -ne '$false') { $findings.Add("$where OpenSubKey without explicit writable=`$false") }
            else { $infos.Add("$where OpenSubKey(..., `$false)  (read-only handle)") }
        }
        if ($member -match '^Write(Byte|Int16|Int32|Int64|IntPtr)$') {
            $target = @($m.Arguments)[0].Extent.Text
            if ($target -notin '$p', '$us') { $findings.Add("$where Marshal.$member targets '$target' (not a tool-allocated buffer)") }
        }
        if ($member -match '^(Replace|Copy|Move|Delete|Create|WriteAllText)$' -and $m.Expression.Extent.Text -match 'IO\.(File|Directory)') {
            $findings.Add("$where file-system modification API: $($m.Extent.Text)")
        }
        if ($member -eq 'Open' -and $m.Expression.Extent.Text -match 'System\.IO\.File') {
            if ($m.Extent.Text -notmatch 'FileMode\]::CreateNew') { $findings.Add("$where File.Open without FileMode.CreateNew") }
        }
    }
    # ---- access masks / Add-Type / file cmdlets ----
    $src = $ast.Extent.Text
    foreach ($line in ($src -split "`n")) {
        if ($line -match 'Add-Type' -and $line -notmatch 'Add-Type -AssemblyName System\.IO\.Compression\s*$' -and $line -notmatch '^\s*(#|\*)|Add-Type compilation|unlike Add-Type') {
            $findings.Add("$name Add-Type used for something other than loading System.IO.Compression: $($line.Trim())")
        }
        if ($line -match 'Export-Csv' -and $line -notmatch '-NoClobber') { $findings.Add("$name Export-Csv without -NoClobber") }
    }
}

# ---- native access masks (must be the read-only values) ----
$native = $asts['CISAudit.Native.psm1'].Extent.Text
$expectMask = @{ 'POLICY_VIEW_LOCAL_INFORMATION_AND_LOOKUP' = '0x801'; 'SAM_SERVER_CONNECT_AND_LOOKUP' = '0x21'; 'DOMAIN_READ_PASSWORD_PARAMETERS' = '0x1' }
foreach ($k in $expectMask.Keys) {
    if ($native -match ('\$script:{0}\s*=\s*\[UInt32\](0x[0-9A-Fa-f]+)' -f $k)) {
        if ($Matches[1] -ne $expectMask[$k]) { $findings.Add("Access mask $k = $($Matches[1]) (expected read-only $($expectMask[$k]))") }
        else { $infos.Add("Access mask $k = $($Matches[1])  (read/query only)") }
    }
    else { $findings.Add("Access mask $k not found") }
}
$pinvoke = [regex]::Matches($native, "@\('(\w+\.dll)',\s*'(\w+)'") | ForEach-Object { $_.Groups[2].Value }
$okApis = 'LsaOpenPolicy', 'LsaEnumerateAccountsWithUserRight', 'LsaQueryInformationPolicy', 'LsaFreeMemory', 'LsaClose', 'LsaNtStatusToWinError',
    'SamConnect', 'SamOpenDomain', 'SamQueryInformationDomain', 'SamFreeMemory', 'SamCloseHandle', 'NetUserModalsGet', 'NetApiBufferFree'
foreach ($api in $pinvoke) { if ($okApis -notcontains $api) { $findings.Add("Native API not on read-only allow-list: $api") } else { $infos.Add("Native API $api (query / free / close)") } }

Write-Host "Files scanned: $($files.Count)" -ForegroundColor Cyan
$infos | Sort-Object -Unique | ForEach-Object { Write-Host "  [ok] $_" -ForegroundColor DarkGray }
if ($findings.Count) {
    $findings | ForEach-Object { Write-Host "  [FINDING] $_" -ForegroundColor Red }
    Write-Host "RESULT: $($findings.Count) finding(s)" -ForegroundColor Red
    exit 1
}
Write-Host 'RESULT: PASS - no command or API that can modify the audited system was found.' -ForegroundColor Green
exit 0
