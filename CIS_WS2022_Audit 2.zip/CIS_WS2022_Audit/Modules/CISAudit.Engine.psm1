#Requires -Version 5.1
# CISAudit-Version: 1.2.0
<#
.SYNOPSIS
    Evaluation engine: applies each CIS recommendation's check to pre-collected (read-only) host data
    and builds the result record (all benchmark details + expected / actual / evidence / outcome).
#>
Set-StrictMode -Version Latest

function New-CISOutcome {
    param([string]$Result, [string]$Actual, [string]$Evidence, [string]$Command, $ActualNumber = $null, [string[]]$Extra = @())
    [pscustomobject]@{ Result = $Result; Actual = $Actual; Evidence = $Evidence; Command = $Command
        NotConfigured = $false; ActualNumber = $ActualNumber; Extra = $Extra }
}

function Format-CISPrincipalList {
    param([string[]]$Sid)
    if (-not $Sid -or $Sid.Count -eq 0) { return 'No One' }
    return (($Sid | ForEach-Object { '{0} ({1})' -f (Resolve-CISSidName -Sid $_), $_ }) -join '; ')
}

function Invoke-CISUserRightCheck {
    param($Check, $Context)
    $cmd = "LsaEnumerateAccountsWithUserRight('$($Check.right)')  |  GUI: secpol.msc > Local Policies > User Rights Assignment > $($Check.rightName)  |  gpresult /h (RSoP)"
    if ($Context.UserRightsError) { return New-CISOutcome 'Error' '' ("User rights could not be read: " + $Context.UserRightsError) $cmd }
    $assigned = @($Context.UserRights[$Check.right] | Where-Object { $_ })
    $required = @($Check.principals | ForEach-Object { $_.sid })
    $optional = @($Check.optional | ForEach-Object { $_.sid })
    $actual = Format-CISPrincipalList -Sid $assigned
    if ($Check.mode -eq 'include') {
        $missing = @($required | Where-Object { $assigned -notcontains $_ })
        $pass = ($missing.Count -eq 0)
        $detail = if ($pass) { 'All required principals are assigned.' } else { 'MISSING required principal(s): ' + (($Check.principals | Where-Object { $missing -contains $_.sid } | ForEach-Object { "$($_.name) ($($_.sid))" }) -join '; ') }
    }
    else {
        $allowed = $required + $optional
        $extra = @($assigned | Where-Object { $allowed -notcontains $_ })
        $pass = ($extra.Count -eq 0)
        $detail = if ($pass) { 'No principals outside the approved list.' } else { 'UNAPPROVED principal(s): ' + (Format-CISPrincipalList -Sid $extra) }
    }
    $evidence = "Right: $($Check.right) ($($Check.rightName))`nAssigned: $actual`n$detail"
    $res = if ($pass) { 'Compliant' } else { 'Non-Compliant' }
    $extraSids = if ($Check.mode -eq 'include') { @() } else { @($extra) }
    return New-CISOutcome $res $actual $evidence $cmd $null $extraSids
}

function Invoke-CISAuditPolCheck {
    param($Check, $Context)
    $cmd = 'auditpol /get /subcategory:"{0}"' -f $Check.guid
    if ($Context.AuditPolicyError) { return New-CISOutcome 'Error' '' ('auditpol could not be queried: ' + $Context.AuditPolicyError) $cmd }
    $e = $Context.AuditPolicy[$Check.guid.ToUpperInvariant()]
    if ($null -eq $e) { return New-CISOutcome 'Error' '' "Subcategory $($Check.subcategory) $($Check.guid) not returned by auditpol." $cmd }
    if ($null -eq $e.Flags) { return New-CISOutcome 'Error' $e.Setting "Unrecognised auditpol setting text '$($e.Setting)' (non-English OS?). Verify manually." $cmd }
    $req = [int]$Check.required
    $pass = if ($req -eq 3) { $e.Flags -eq 3 } elseif ($Check.exact) { $e.Flags -eq $req } else { ($e.Flags -band $req) -eq $req }
    $want = @{ 1 = 'Success'; 2 = 'Failure'; 3 = 'Success and Failure' }[$req]
    $rule = if ($req -eq 3) { "must be 'Success and Failure'" } elseif ($Check.exact) { "must be '$want'" } else { "must include '$want'" }
    $evidence = "auditpol: Subcategory '$($e.Subcategory)' $($Check.guid) Inclusion Setting = '$($e.Setting)'; rule: $rule"
    $res = if ($pass) { 'Compliant' } else { 'Non-Compliant' }
    return New-CISOutcome $res $e.Setting $evidence $cmd
}

function Invoke-CISPolicyCheck {
    param($Check, $Context)
    $cmd = 'net accounts  |  secpol.msc > Account Policies / Security Options  |  NetUserModalsGet + SamQueryInformationDomain'
    $ap = $Context.AccountPolicy
    if ($null -eq $ap) { return New-CISOutcome 'Error' '' ('Account policy could not be read: ' + $Context.AccountPolicyError) $cmd }
    $v = $ap.($Check.field)
    $raw = "NetUserModalsGet L0=[$($ap.RawUserModals0)] L3=[$($ap.RawUserModals3)] SAM PasswordProperties=$($ap.RawPasswordProperties)"
    if ($null -eq $v) { return New-CISOutcome 'Error' '' ("$($Check.field) unavailable. SAM error: $($ap.SamError). $raw") $cmd }
    $display = if ($Check.unit -eq 'flag') { if ([int]$v -eq 1) { 'Enabled' } else { 'Disabled' } } else { "$v $($Check.unit)" }
    if ($Check.op -eq 'eq') { $pass = ([int]$v -eq [int]$Check.value) }
    elseif ($v -is [string] -and $v -eq 'Forever') { $pass = [bool]($Check.PSObject.Properties.Name -contains 'foreverOk') ; $display = 'Until an administrator unlocks (Forever)' }
    else { $pass = ([long]$v -ge [long]$Check.min -and ($null -eq $Check.max -or [long]$v -le [long]$Check.max)) }
    $evidence = "$($Check.field) = $display. $raw"
    $res = if ($pass) { 'Compliant' } else { 'Non-Compliant' }
    $num = if ($v -is [string]) { $null } else { [long]$v }
    return New-CISOutcome $res $display $evidence $cmd $num
}

function Invoke-CISAccountCheck {
    param($Check, $Context)
    $cmd = "Get-CimInstance Win32_UserAccount -Filter `"SID='<DomainSID>-500|501'`"  |  secpol.msc > Security Options > Accounts"
    if ($Context.AccountsError) { return New-CISOutcome 'Error' '' ('Built-in accounts could not be read: ' + $Context.AccountsError) $cmd }
    $rid = if ($Check.test -eq 'AdminRenamed') { 500 } else { 501 }
    $a = $Context.Accounts[$rid]
    if ($a.Error) { return New-CISOutcome 'Error' '' "RID $rid ($($a.Sid)): $($a.Error)" $cmd }
    switch ($Check.test) {
        'AdminRenamed' { $pass = ($a.Name -ine 'Administrator'); $actual = "Name = '$($a.Name)'" }
        'GuestRenamed' { $pass = ($a.Name -ine 'Guest'); $actual = "Name = '$($a.Name)'" }
        'GuestDisabled' {
            if ($null -eq $a.Disabled) { return New-CISOutcome 'Error' '' "Could not read enabled state of $($a.Sid)" $cmd }
            $pass = [bool]$a.Disabled; $actual = if ($a.Disabled) { 'Disabled' } else { 'Enabled' }
        }
    }
    $evidence = "Built-in account RID $rid, SID $($a.Sid), Name '$($a.Name)', Disabled=$($a.Disabled)"
    $res = if ($pass) { 'Compliant' } else { 'Non-Compliant' }
    return New-CISOutcome $res $actual $evidence $cmd
}

function Invoke-CISControl {
    <# Evaluates one control and returns the full report row. #>
    param([Parameter(Mandatory)]$Control, [Parameter(Mandatory)]$Context)
    $prof = @($Control.profiles | Where-Object { $_.role -eq $Context.Role })
    if ($prof.Count -eq 0) {
        $o = New-CISOutcome 'Not Applicable' '' ("Recommendation applies to {0} only; host evaluated as {1}." -f $Control.appliesTo, $Context.Role) ''
    }
    elseif ($Context.Levels -notcontains $prof[0].level) {
        $o = New-CISOutcome 'Not Applicable' '' ("Profile {0} not selected (-Level {1})." -f $prof[0].level, $Context.LevelParam) ''
    }
    else {
        try {
            switch ($Control.check.type) {
                'registry' { $o = Invoke-CISRegistryCheck -Check $Control.check -Context $Context }
                'userright' { $o = Invoke-CISUserRightCheck -Check $Control.check -Context $Context }
                'auditpol' { $o = Invoke-CISAuditPolCheck -Check $Control.check -Context $Context }
                'policy' { $o = Invoke-CISPolicyCheck -Check $Control.check -Context $Context }
                'account' { $o = Invoke-CISAccountCheck -Check $Control.check -Context $Context }
                default { $o = New-CISOutcome 'Error' '' "Unknown check type $($Control.check.type)" '' }
            }
        }
        catch { $o = New-CISOutcome 'Error' '' ('Evaluation error: ' + $_.Exception.Message) '' }
    }
    if ($Context.ContainsKey('Meta')) { $Context.Meta[$Control.id] = $o }
    [pscustomobject][ordered]@{
        'Control ID'           = $Control.id
        'Section'              = $Control.section
        'Title'                = $Control.title
        'Profile Level'        = $Control.levelText
        'Applies To'           = $Control.appliesTo
        'Assessment Status'    = $Control.assessment
        'Result'               = $o.Result
        'Severity'             = $Control.severity.base
        'Finding Severity'     = ''
        'Severity Rationale'   = $Control.severity.rationale
        'Severity Adjustment'  = ''
        'Expected Value'       = $Control.expected
        'Actual Value'         = $o.Actual
        'Evidence'             = $o.Evidence
        'Evidence Command'     = $o.Command
        'Description'          = $Control.description
        'Rationale'            = $Control.rationale
        'Impact'               = $Control.impact
        'Audit Procedure'      = $Control.audit
        'Remediation'          = $Control.remediation
        'Default Value'        = $Control.defaultValue
        'References'           = $Control.references
        'CIS Controls Mapping' = $Control.cisControls
        'Hostname'             = $Context.ComputerName
        'Audit Timestamp'      = $Context.AuditTime
    }
}

Export-ModuleMember -Function Invoke-CISControl
