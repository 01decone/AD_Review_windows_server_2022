#Requires -Version 5.1
# CISAudit-Version: 1.2.0
<#
.SYNOPSIS
    Minimal dependency-free .xlsx writer (Office Open XML) used for the audit report.
.DESCRIPTION
    Builds the workbook with System.IO.Compression.ZipArchive. Excel does NOT need to be installed.
    Writes only the report file that the caller asks for.
#>
Set-StrictMode -Version Latest

$script:InvalidXml = New-Object System.Text.RegularExpressions.Regex('[\x00-\x08\x0B\x0C\x0E-\x1F]')

function ConvertTo-CISXmlText {
    param([AllowNull()][string]$Text)
    if ($null -eq $Text) { return '' }
    $t = $script:InvalidXml.Replace($Text, '')
    if ($t.Length -gt 32000) { $t = $t.Substring(0, 32000) + ' ...[truncated]' }
    return [System.Security.SecurityElement]::Escape($t)
}

function Get-CISColumnLetter {
    param([int]$Index)   # 1-based
    $s = ''
    while ($Index -gt 0) { $m = ($Index - 1) % 26; $s = [char](65 + $m) + $s; $Index = [int][math]::Floor(($Index - $m) / 26) }
    return $s
}

function Get-CISResultStyle {
    param([string]$Value)
    switch ($Value) {
        'Compliant' { return 3 }
        'Non-Compliant' { return 4 }
        'Not Applicable' { return 5 }
        'Manual Review' { return 6 }
        'Error' { return 6 }
        'Critical' { return 8 }
        'High' { return 9 }
        'Medium' { return 10 }
        'Low' { return 11 }
        'Informational' { return 12 }
        'None' { return 5 }
        default { return 2 }
    }
}

function New-CISSheetXml {
    param([string[]]$Columns, [object[]]$Rows, [hashtable]$Widths, [string[]]$ResultColumn)
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
    [void]$sb.Append('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">')
    [void]$sb.Append('<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>')
    [void]$sb.Append('<cols>')
    for ($i = 0; $i -lt $Columns.Count; $i++) {
        $w = if ($Widths -and $Widths.ContainsKey($Columns[$i])) { $Widths[$Columns[$i]] } else { 30 }
        [void]$sb.AppendFormat('<col min="{0}" max="{0}" width="{1}" customWidth="1"/>', ($i + 1), $w)
    }
    [void]$sb.Append('</cols><sheetData>')
    [void]$sb.Append('<row r="1">')
    for ($i = 0; $i -lt $Columns.Count; $i++) {
        [void]$sb.AppendFormat('<c r="{0}1" t="inlineStr" s="1"><is><t xml:space="preserve">{1}</t></is></c>', (Get-CISColumnLetter ($i + 1)), (ConvertTo-CISXmlText $Columns[$i]))
    }
    [void]$sb.Append('</row>')
    $r = 1
    foreach ($row in $Rows) {
        $r++
        [void]$sb.AppendFormat('<row r="{0}">', $r)
        for ($i = 0; $i -lt $Columns.Count; $i++) {
            $val = "$($row.($Columns[$i]))"
            $style = if ($ResultColumn -contains $Columns[$i]) { Get-CISResultStyle $val } else { 2 }
            [void]$sb.AppendFormat('<c r="{0}{1}" t="inlineStr" s="{2}"><is><t xml:space="preserve">{3}</t></is></c>', (Get-CISColumnLetter ($i + 1)), $r, $style, (ConvertTo-CISXmlText $val))
        }
        [void]$sb.Append('</row>')
    }
    [void]$sb.Append('</sheetData>')
    if ($Rows.Count -gt 0) { [void]$sb.AppendFormat('<autoFilter ref="A1:{0}{1}"/>', (Get-CISColumnLetter $Columns.Count), $r) }
    [void]$sb.Append('</worksheet>')
    return $sb.ToString()
}

function Get-CISStylesXml {
    return @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="3"><font><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="10"/><name val="Calibri"/></font></fonts>
<fills count="12"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF1F3864"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFC6EFCE"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE7E6E6"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFEB9C"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF7B0000"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE0452B"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF4B183"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFDDEBF7"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right><top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="13">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="1" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="10" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="11" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>
'@
}

function Export-CISXlsx {
    <#
    .SYNOPSIS Writes an .xlsx workbook. -Sheets: array of @{ Name; Columns; Rows; Widths; ResultColumn }
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][object[]]$Sheets)
    Add-Type -AssemblyName System.IO.Compression
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    $parts = [ordered]@{}
    $ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
    $wbSheets = ''; $wbRels = ''
    for ($i = 0; $i -lt $Sheets.Count; $i++) {
        $n = $i + 1
        $s = $Sheets[$i]
        $ct += '<Override PartName="/xl/worksheets/sheet{0}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' -f $n
        $wbSheets += '<sheet name="{0}" sheetId="{1}" r:id="rId{1}"/>' -f (ConvertTo-CISXmlText $s.Name), $n
        $wbRels += '<Relationship Id="rId{0}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{0}.xml"/>' -f $n
        $parts["xl/worksheets/sheet$n.xml"] = New-CISSheetXml -Columns $s.Columns -Rows @($s.Rows) -Widths $s.Widths -ResultColumn $s.ResultColumn
    }
    $stylesId = $Sheets.Count + 1
    $wbRels += '<Relationship Id="rId{0}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' -f $stylesId
    $parts['[Content_Types].xml'] = $ct + '</Types>'
    $parts['_rels/.rels'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    $parts['xl/workbook.xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + $wbSheets + '</sheets></workbook>'
    $parts['xl/_rels/workbook.xml.rels'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + $wbRels + '</Relationships>'
    $parts['xl/styles.xml'] = Get-CISStylesXml
    $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::CreateNew)
    try {
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($k in $parts.Keys) {
                $entry = $zip.CreateEntry($k)
                $w = New-Object System.IO.StreamWriter($entry.Open(), $utf8)
                try { $w.Write($parts[$k]) } finally { $w.Dispose() }
            }
        }
        finally { $zip.Dispose() }
    }
    finally { $fs.Dispose() }
}

Export-ModuleMember -Function Export-CISXlsx
