#Requires -Version 5.1
# CISAudit-Version: 1.2.0
<#
.SYNOPSIS
    Read-only native Windows API readers (LSA, SAM, NetAPI) used by the CIS audit.
.DESCRIPTION
    P/Invoke signatures are defined IN MEMORY with Reflection.Emit (AssemblyBuilderAccess.Run).
    Nothing is compiled or written to disk (unlike Add-Type, which writes temp files).
    Only QUERY / VIEW access masks are requested and every handle / buffer is released.
    Functions in this module never call any Set*, Add*, Remove* or Write* Windows API.
#>
Set-StrictMode -Version Latest

$script:NativeType = $null
$script:Marshal = [System.Runtime.InteropServices.Marshal]

# NTSTATUS values that simply mean "nobody holds this right" (decimal to avoid PS hex sign issues)
$script:STATUS_NO_MORE_ENTRIES = [UInt32]2147483674          # 0x8000001A
$script:STATUS_OBJECT_NAME_NOT_FOUND = [UInt32]3221225524    # 0xC0000034

# Read-only access masks
$script:POLICY_VIEW_LOCAL_INFORMATION_AND_LOOKUP = [UInt32]0x801   # POLICY_VIEW_LOCAL_INFORMATION | POLICY_LOOKUP_NAMES
$script:SAM_SERVER_CONNECT_AND_LOOKUP = [UInt32]0x21               # SAM_SERVER_CONNECT | SAM_SERVER_LOOKUP_DOMAIN
$script:DOMAIN_READ_PASSWORD_PARAMETERS = [UInt32]0x1

function Get-CISNativeType {
    if ($null -ne $script:NativeType) { return $script:NativeType }
    $name = 'CISAuditNative' + [guid]::NewGuid().ToString('N')
    $asm = [System.Reflection.Emit.AssemblyBuilder]::DefineDynamicAssembly(
        (New-Object System.Reflection.AssemblyName($name)), [System.Reflection.Emit.AssemblyBuilderAccess]::Run)
    $module = $asm.DefineDynamicModule($name)
    $tb = $module.DefineType('CISAudit.Native', 'Public, Class, Sealed')
    $pRef = [IntPtr].MakeByRefType()
    $uRef = [UInt32].MakeByRefType()
    $defs = @(
        @('advapi32.dll', 'LsaOpenPolicy', @([IntPtr], [IntPtr], [UInt32], $pRef)),
        @('advapi32.dll', 'LsaEnumerateAccountsWithUserRight', @([IntPtr], [IntPtr], $pRef, $uRef)),
        @('advapi32.dll', 'LsaQueryInformationPolicy', @([IntPtr], [Int32], $pRef)),
        @('advapi32.dll', 'LsaFreeMemory', @([IntPtr])),
        @('advapi32.dll', 'LsaClose', @([IntPtr])),
        @('advapi32.dll', 'LsaNtStatusToWinError', @([UInt32])),
        @('samlib.dll', 'SamConnect', @([IntPtr], $pRef, [UInt32], [IntPtr])),
        @('samlib.dll', 'SamOpenDomain', @([IntPtr], [UInt32], [IntPtr], $pRef)),
        @('samlib.dll', 'SamQueryInformationDomain', @([IntPtr], [Int32], $pRef)),
        @('samlib.dll', 'SamFreeMemory', @([IntPtr])),
        @('samlib.dll', 'SamCloseHandle', @([IntPtr])),
        @('netapi32.dll', 'NetUserModalsGet', @([IntPtr], [UInt32], $pRef)),
        @('netapi32.dll', 'NetApiBufferFree', @([IntPtr]))
    )
    foreach ($d in $defs) {
        $m = $tb.DefinePInvokeMethod($d[1], $d[0],
            [System.Reflection.MethodAttributes]'Public, Static, PinvokeImpl, HideBySig',
            [System.Reflection.CallingConventions]::Standard, [UInt32], [Type[]]$d[2],
            [System.Runtime.InteropServices.CallingConvention]::Winapi,
            [System.Runtime.InteropServices.CharSet]::Unicode)
        $m.SetImplementationFlags([System.Reflection.MethodImplAttributes]::PreserveSig)
    }
    $script:NativeType = $tb.CreateType()
    return $script:NativeType
}

function ConvertTo-CISUInt32 {
    param([Parameter(Mandatory)][int]$Value)
    return [BitConverter]::ToUInt32([BitConverter]::GetBytes($Value), 0)
}

function New-CISZeroedBuffer {
    param([Parameter(Mandatory)][int]$Size)
    $p = $script:Marshal::AllocHGlobal($Size)
    for ($i = 0; $i -lt $Size; $i++) { $script:Marshal::WriteByte($p, $i, 0) }
    return $p
}

function New-CISObjectAttributes {
    # LSA_OBJECT_ATTRIBUTES / OBJECT_ATTRIBUTES: zeroed, Length set (48 bytes x64, 24 bytes x86)
    $size = if ([IntPtr]::Size -eq 8) { 48 } else { 24 }
    $p = New-CISZeroedBuffer -Size $size
    $script:Marshal::WriteInt32($p, 0, $size)
    return $p
}

function Get-CISNtStatusMessage {
    param([UInt32]$Status, [string]$Api)
    $t = Get-CISNativeType
    $win32 = $t::LsaNtStatusToWinError($Status)
    $msg = (New-Object System.ComponentModel.Win32Exception([int]$win32)).Message
    return ('{0} failed: NTSTATUS 0x{1:X8} / Win32 {2} ({3})' -f $Api, $Status, $win32, $msg)
}

function Open-CISLsaPolicy {
    $t = Get-CISNativeType
    $oa = New-CISObjectAttributes
    $handle = [IntPtr]::Zero
    try { $st = $t::LsaOpenPolicy([IntPtr]::Zero, $oa, $script:POLICY_VIEW_LOCAL_INFORMATION_AND_LOOKUP, [ref]$handle) }
    finally { $script:Marshal::FreeHGlobal($oa) }
    if ($st -ne 0) { throw (Get-CISNtStatusMessage -Status $st -Api 'LsaOpenPolicy') }
    return $handle
}

function Get-CISUserRightAssignment {
    <# Returns a hashtable: privilege constant -> string[] of SIDs currently holding it (read-only LSA query). #>
    [CmdletBinding()]
    param([Parameter(Mandatory)][string[]]$Right)
    $t = Get-CISNativeType
    $policy = Open-CISLsaPolicy
    $result = @{}
    try {
        foreach ($r in ($Right | Select-Object -Unique)) {
            $strBuf = $script:Marshal::StringToHGlobalUni($r)
            $usSize = if ([IntPtr]::Size -eq 8) { 16 } else { 8 }
            $us = New-CISZeroedBuffer -Size $usSize
            $buf = [IntPtr]::Zero
            $count = [UInt32]0
            try {
                $script:Marshal::WriteInt16($us, 0, [int16]($r.Length * 2))
                $script:Marshal::WriteInt16($us, 2, [int16](($r.Length * 2) + 2))
                $script:Marshal::WriteIntPtr($us, [IntPtr]::Size, $strBuf)
                $st = $t::LsaEnumerateAccountsWithUserRight($policy, $us, [ref]$buf, [ref]$count)
            }
            finally {
                $script:Marshal::FreeHGlobal($us)
                $script:Marshal::FreeHGlobal($strBuf)
            }
            $sids = New-Object System.Collections.Generic.List[string]
            if ($st -eq 0) {
                try {
                    for ($i = 0; $i -lt $count; $i++) {
                        $pSid = $script:Marshal::ReadIntPtr($buf, $i * [IntPtr]::Size)
                        $sids.Add((New-Object System.Security.Principal.SecurityIdentifier($pSid)).Value)
                    }
                }
                finally { [void]$t::LsaFreeMemory($buf) }
            }
            elseif ($st -ne $script:STATUS_NO_MORE_ENTRIES -and $st -ne $script:STATUS_OBJECT_NAME_NOT_FOUND) {
                throw (Get-CISNtStatusMessage -Status $st -Api "LsaEnumerateAccountsWithUserRight($r)")
            }
            $result[$r] = $sids.ToArray()
        }
    }
    finally { [void]$t::LsaClose($policy) }
    return $result
}

function Get-CISAccountDomainSid {
    <# Machine (member server) or domain (DC) account-domain SID via LsaQueryInformationPolicy(PolicyAccountDomainInformation). #>
    $t = Get-CISNativeType
    $policy = Open-CISLsaPolicy
    $buf = [IntPtr]::Zero
    try {
        $st = $t::LsaQueryInformationPolicy($policy, 5, [ref]$buf)
        if ($st -ne 0) { throw (Get-CISNtStatusMessage -Status $st -Api 'LsaQueryInformationPolicy') }
        try {
            $offset = if ([IntPtr]::Size -eq 8) { 16 } else { 8 }
            $pSid = $script:Marshal::ReadIntPtr($buf, $offset)
            return (New-Object System.Security.Principal.SecurityIdentifier($pSid))
        }
        finally { [void]$t::LsaFreeMemory($buf) }
    }
    finally { [void]$t::LsaClose($policy) }
}

function Get-CISSamPasswordProperties {
    <# DOMAIN_PASSWORD_INFORMATION via SamQueryInformationDomain (read-only DOMAIN_READ_PASSWORD_PARAMETERS). #>
    $t = Get-CISNativeType
    $domSid = Get-CISAccountDomainSid
    $bytes = New-Object byte[] ($domSid.BinaryLength)
    $domSid.GetBinaryForm($bytes, 0)
    $sidPtr = $script:Marshal::AllocHGlobal($bytes.Length)
    $script:Marshal::Copy($bytes, 0, $sidPtr, $bytes.Length)
    $oa = New-CISObjectAttributes
    $srv = [IntPtr]::Zero; $dom = [IntPtr]::Zero; $buf = [IntPtr]::Zero
    try {
        $st = $t::SamConnect([IntPtr]::Zero, [ref]$srv, $script:SAM_SERVER_CONNECT_AND_LOOKUP, $oa)
        if ($st -ne 0) { throw (Get-CISNtStatusMessage -Status $st -Api 'SamConnect') }
        $st = $t::SamOpenDomain($srv, $script:DOMAIN_READ_PASSWORD_PARAMETERS, $sidPtr, [ref]$dom)
        if ($st -ne 0) { throw (Get-CISNtStatusMessage -Status $st -Api 'SamOpenDomain') }
        $st = $t::SamQueryInformationDomain($dom, 1, [ref]$buf)
        if ($st -ne 0) { throw (Get-CISNtStatusMessage -Status $st -Api 'SamQueryInformationDomain') }
        return [pscustomobject]@{
            MinPasswordLength     = [int][UInt16]($script:Marshal::ReadInt16($buf, 0) -band 0xFFFF)
            PasswordHistoryLength = [int][UInt16]($script:Marshal::ReadInt16($buf, 2) -band 0xFFFF)
            PasswordProperties    = ConvertTo-CISUInt32 -Value ($script:Marshal::ReadInt32($buf, 4))
            DomainSid             = $domSid.Value
        }
    }
    finally {
        if ($buf -ne [IntPtr]::Zero) { [void]$t::SamFreeMemory($buf) }
        if ($dom -ne [IntPtr]::Zero) { [void]$t::SamCloseHandle($dom) }
        if ($srv -ne [IntPtr]::Zero) { [void]$t::SamCloseHandle($srv) }
        $script:Marshal::FreeHGlobal($oa)
        $script:Marshal::FreeHGlobal($sidPtr)
    }
}

function Get-CISUserModals {
    <# NetUserModalsGet level 0 (password) or 3 (lockout). Returns UInt32 array of the structure's DWORD fields. #>
    param([Parameter(Mandatory)][ValidateSet(0, 3)][int]$Level)
    $t = Get-CISNativeType
    $buf = [IntPtr]::Zero
    $st = $t::NetUserModalsGet([IntPtr]::Zero, [UInt32]$Level, [ref]$buf)
    if ($st -ne 0) {
        throw ('NetUserModalsGet(level {0}) failed: {1}' -f $Level, (New-Object System.ComponentModel.Win32Exception([int]$st)).Message)
    }
    try {
        $n = if ($Level -eq 0) { 5 } else { 3 }
        $vals = for ($i = 0; $i -lt $n; $i++) { ConvertTo-CISUInt32 -Value ($script:Marshal::ReadInt32($buf, $i * 4)) }
        return , ([UInt32[]]$vals)
    }
    finally { [void]$t::NetApiBufferFree($buf) }
}

Export-ModuleMember -Function Get-CISNativeType, Get-CISUserRightAssignment, Get-CISAccountDomainSid,
    Get-CISSamPasswordProperties, Get-CISUserModals, ConvertTo-CISUInt32
