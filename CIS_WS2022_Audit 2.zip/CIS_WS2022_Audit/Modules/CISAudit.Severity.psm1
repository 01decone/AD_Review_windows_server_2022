#Requires -Version 5.1
# CISAudit-Version: 1.2.0
<#
.SYNOPSIS
    Context-aware severity rating for CIS findings.
.DESCRIPTION
    Each recommendation carries a BASE severity (inherent risk if the setting is actively insecure) and rules.
    After all checks run, the FINDING severity of every Non-Compliant result is derived from:
      1. value-specific rules (e.g. LmCompatibilityLevel <= 2 -> Critical; AlwaysInstallElevated only in HKLM -> High)
      2. "not configured" where the Windows default already equals the recommendation -> Low / Informational
      3. user-rights context (broad groups such as Everyone raise; service SIDs only lower)
      4. compensating controls (e.g. SMB encryption required compensates SMB signing, LAPS compensates
         local-admin network logon, NLA compensates RDP security layer, legacy LAPS compensates Windows LAPS)
      5. feature not in use (Print Spooler / RDP / WinRM disabled, SMBv1 not installed, Guest disabled)
    Facts are gathered with the same READ-ONLY registry reader used by the audit.
#>
Set-StrictMode -Version Latest

$script:Rank = @{ 'None' = 0; 'Informational' = 1; 'Low' = 2; 'Medium' = 3; 'High' = 4; 'Critical' = 5 }
$script:Names = @('None', 'Informational', 'Low', 'Medium', 'High', 'Critical')
$script:BroadSid = '^(S-1-1-0|S-1-5-7|S-1-5-11|S-1-5-32-545|S-1-5-32-546|S-1-5-4|S-1-5-2|S-1-5-21-[\d-]+-(513|514|515))$'
$script:ServiceSid = '^(S-1-5-(80|82|83|90|96)-[\d-]+|S-1-5-19|S-1-5-20|S-1-5-6|S-1-5-17|S-1-5-32-568)$'

function Get-CISRegNumber {
    <# Returns @{ Err; KeyExists; Exists; N }. Err = $true when the value could not be read (facts then stay unknown). #>
    param([string]$Key, [string]$Name)
    $r = Get-CISRegistryValue -Hive HKLM -Key $Key -Name $Name
    $n = $null; $tmp = 0L
    if ($r.ValueExists -and [long]::TryParse("$($r.Value)", [ref]$tmp)) { $n = $tmp }
    return @{ Err = [bool]$r.Error; KeyExists = $r.KeyExists; Exists = $r.ValueExists; N = $n }
}

function Get-CISServiceDisabled {
    <# $true = service disabled or not installed; $false = present and not disabled; $null = unknown (read error). #>
    param([string]$Service)
    $r = Get-CISRegNumber "SYSTEM\CurrentControlSet\Services\$Service" 'Start'
    if ($r.Err) { return $null }
    if (-not $r.KeyExists) { return $true }
    return ($r.N -eq 4)
}

function Get-CISSeverityFact {
    <# Read-only facts used by the severity rules. Any fact that cannot be read is left $null (no adjustment is made). #>
    param([Parameter(Mandatory)][hashtable]$Context, [Parameter(Mandatory)]$SystemInfo)
    $f = @{}
    $f.IsDC = ($Context.Role -eq 'DC')
    $f.PartOfDomain = [bool]$SystemInfo.PartOfDomain
    $f.SpoolerDisabled = Get-CISServiceDisabled 'Spooler'
    $f.WinRMDisabled = Get-CISServiceDisabled 'WinRM'
    $rp = Get-CISRegNumber 'SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' 'fDenyTSConnections'
    $rl = Get-CISRegNumber 'SYSTEM\CurrentControlSet\Control\Terminal Server' 'fDenyTSConnections'
    $f.RDPDisabled = if ($rp.Err -or $rl.Err) { $null } elseif ($rp.Exists) { $rp.N -eq 1 } else { $rl.N -eq 1 }
    $m = Get-CISRegNumber 'SYSTEM\CurrentControlSet\Services\mrxsmb10' 'Start'
    $f.SMB1NotInstalled = if ($m.Err) { $null } else { -not $m.KeyExists }
    $enc = Get-CISRegNumber 'SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' 'EncryptData'
    $rej = Get-CISRegNumber 'SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' 'RejectUnencryptedAccess'
    $f.SMBServerEncryptionRequired = if ($enc.Err -or $rej.Err) { $null } else { ($enc.N -eq 1 -and (-not $rej.Exists -or $rej.N -eq 1)) }
    $l = Get-CISRegNumber 'SOFTWARE\Policies\Microsoft Services\AdmPwd' 'AdmPwdEnabled'
    $f.LegacyLAPS = if ($l.Err) { $null } else { $l.N -eq 1 }
    $dp = Get-CISRegistryValue -Hive HKLM -Key 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'DefaultPassword'
    $f.DefaultPasswordPresent = if ($dp.Error) { $null } else { $dp.ValueExists }   # existence only - the value is never read into the report
    $f.AIEUserEnabled = $false
    foreach ($sid in @($Context.UserSids)) {
        $u = Get-CISRegistryValue -Hive HKU -UserSid $sid -Key 'Software\Policies\Microsoft\Windows\Installer' -Name 'AlwaysInstallElevated'
        if ($u.Error) { $f.AIEUserEnabled = $null; break }
        if ($u.ValueExists -and "$($u.Value)" -eq '1') { $f.AIEUserEnabled = $true }
    }
    foreach ($p in @(@('Domain', 'DomainProfile', 'DomainProfile'), @('Private', 'PrivateProfile', 'StandardProfile'), @('Public', 'PublicProfile', 'PublicProfile'))) {
        $pol = 'SOFTWARE\Policies\Microsoft\WindowsFirewall\{0}' -f $p[1]
        $loc = 'SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\{0}' -f $p[2]
        foreach ($pair in @(@('On', 'EnableFirewall'), @('Block', 'DefaultInboundAction'))) {
            $a = Get-CISRegNumber $pol $pair[1]; $b = Get-CISRegNumber $loc $pair[1]
            $eff = if ($a.Exists) { $a.N } else { $b.N }
            $f["Fw$($p[0])$($pair[0])"] = if ($a.Err -or $b.Err) { $null } else { ($null -eq $eff -or $eff -eq 1) }   # Windows default: on / block
        }
    }
    $ap = $Context.AccountPolicy
    foreach ($k in 'MinPasswordLength', 'LockoutThreshold', 'MaxPasswordAgeDays', 'PasswordHistoryLength') { $f[$k] = if ($ap) { $ap.$k } else { $null } }
    $f.GuestDisabled = $null; $f.AdminDisabled = $null
    if ($Context.Accounts -and $Context.Accounts.ContainsKey(501)) { $f.GuestDisabled = $Context.Accounts[501].Disabled }
    if ($Context.Accounts -and $Context.Accounts.ContainsKey(500)) { $f.AdminDisabled = $Context.Accounts[500].Disabled }
    return $f
}

function Test-CISCompare {
    param($Left, [string]$Op, $Value, $Value2)
    if ($Op -eq 'true') { return ($Left -eq $true) }
    if ($Op -eq 'false') { return ($Left -eq $false) }
    if ($null -eq $Left -or $Left -is [string]) { return $false }
    switch ($Op) {
        'eq' { return ([long]$Left -eq [long]$Value) }
        'ne' { return ([long]$Left -ne [long]$Value) }
        'lt' { return ([long]$Left -lt [long]$Value) }
        'le' { return ([long]$Left -le [long]$Value) }
        'gt' { return ([long]$Left -gt [long]$Value) }
        'ge' { return ([long]$Left -ge [long]$Value) }
        'between' { return ([long]$Left -ge [long]$Value -and [long]$Left -le [long]$Value2) }
    }
    return $false
}

function Test-CISCondition {
    param($Cond, [hashtable]$Facts, [hashtable]$ResultById, $Outcome)
    $names = $Cond.PSObject.Properties.Name
    if ($names -contains 'all') { foreach ($c in $Cond.all) { if (-not (Test-CISCondition $c $Facts $ResultById $Outcome)) { return $false } }; return $true }
    if ($names -contains 'any') { foreach ($c in $Cond.any) { if (Test-CISCondition $c $Facts $ResultById $Outcome) { return $true } }; return $false }
    $v2 = if ($names -contains 'value2') { $Cond.value2 } else { $null }
    $val = if ($names -contains 'value') { $Cond.value } else { $null }
    if ($names -contains 'fact') { return (Test-CISCompare $Facts[$Cond.fact] $Cond.op $val $v2) }
    if ($names -contains 'control') { return ($ResultById[$Cond.control] -eq $Cond.result) }
    if ($names -contains 'actual') { return (Test-CISCompare $Outcome.ActualNumber $Cond.actual $val $v2) }
    return $false
}

function Set-CISFindingSeverity {
    <# Second pass: fills 'Finding Severity' and 'Severity Adjustment' on every report row. #>
    param([Parameter(Mandatory)][object[]]$Rows, [Parameter(Mandatory)][object[]]$Controls, [Parameter(Mandatory)][hashtable]$Context, [Parameter(Mandatory)][hashtable]$Facts)
    $byId = @{}; foreach ($c in $Controls) { $byId[$c.id] = $c }
    $resultById = @{}; foreach ($r in $Rows) { $resultById[$r.'Control ID'] = $r.Result }
    foreach ($row in $Rows) {
        $c = $byId[$row.'Control ID']; $sev = $c.severity
        if ($row.Result -in 'Compliant', 'Not Applicable') { $row.'Finding Severity' = 'None'; continue }
        if ($row.Result -in 'Error', 'Manual Review') {
            $row.'Finding Severity' = $sev.base; $row.'Severity Adjustment' = 'Unverified - rated at base severity until the setting is confirmed.'; continue
        }
        $o = $Context.Meta[$c.id]
        $cur = $script:Rank[$sev.base]; $notes = New-Object System.Collections.Generic.List[string]
        # 1. value-specific 'set' rules (may raise or lower)
        foreach ($rule in @($sev.rules | Where-Object { $_.mode -eq 'set' })) {
            if (Test-CISCondition $rule.when $Facts $resultById $o) { $cur = $script:Rank[$rule.to]; $notes.Add("Set to $($rule.to): $($rule.reason)"); break }
        }
        # 2. not configured, Windows default already secure
        $sd = $sev.secureDefault
        $secureDef = ($sd -eq $true) -or ($sd -eq 'DC' -and $Context.Role -eq 'DC')
        if ($o -and $o.NotConfigured -and $secureDef) {
            $to = if ($cur -ge 4) { 2 } else { 1 }
            if ($to -lt $cur) { $cur = $to; $notes.Add("Lowered to $($script:Names[$to]): policy not configured, but the Windows default already enforces the recommended value (risk = local drift only).") }
        }
        # 3. user-rights context
        if ($c.check.type -eq 'userright' -and $o -and @($o.Extra).Count -gt 0) {
            $broad = @($o.Extra | Where-Object { $_ -match $script:BroadSid })
            $svcOnly = @($o.Extra | Where-Object { $_ -notmatch $script:ServiceSid }).Count -eq 0
            if ($broad.Count -gt 0 -and $cur -lt 5) { $cur++; $notes.Add("Raised to $($script:Names[$cur]): right granted to broad group(s) $($broad -join ', ') - usable by any user.") }
            elseif ($svcOnly -and $cur -gt 2) { $cur--; $notes.Add("Lowered to $($script:Names[$cur]): only service / virtual accounts were added (usually product-required); validate each.") }
        }
        # 4/5. compensating controls and features not in use (only lower)
        foreach ($rule in @($sev.rules | Where-Object { $_.mode -eq 'cap' })) {
            if (-not (Test-CISCondition $rule.when $Facts $resultById $o)) { continue }
            $to = if ($rule.to -eq 'LowOrInfo') { if ($cur -ge 4) { 2 } else { 1 } } else { $script:Rank[$rule.to] }
            if ($to -lt $cur) { $cur = $to; $notes.Add("Lowered to $($script:Names[$to]): $($rule.reason)") }
        }
        $row.'Finding Severity' = $script:Names[$cur]
        $row.'Severity Adjustment' = if ($notes.Count) { $notes -join ' | ' } else { 'No adjustment - base severity applies.' }
    }
}

function Get-CISSeverityRank { param([string]$Name) if ($script:Rank.ContainsKey($Name)) { return $script:Rank[$Name] } return 0 }

Export-ModuleMember -Function Get-CISSeverityFact, Set-CISFindingSeverity, Get-CISSeverityRank
