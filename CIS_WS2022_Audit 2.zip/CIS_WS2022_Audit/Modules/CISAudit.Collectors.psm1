#Requires -Version 5.1
# CISAudit-Version: 1.2.0
<#
.SYNOPSIS
    Read-only data collectors for the CIS Windows Server 2022 audit.
.DESCRIPTION
    Registry access uses Microsoft.Win32.RegistryKey.OpenSubKey(path, writable = $false).
    Audit policy uses 'auditpol.exe /get' (query only). Account data uses CIM / SID translation (query only).
    No function in this module creates, modifies or deletes any system setting.
#>
Set-StrictMode -Version Latest

function Get-CISSystemInfo {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
    $principal = New-Object System.Security.Principal.WindowsPrincipal([System.Security.Principal.WindowsIdentity]::GetCurrent())
    $roleName = @{ 0 = 'Standalone Workstation'; 1 = 'Member Workstation'; 2 = 'Standalone Server'; 3 = 'Member Server'; 4 = 'Backup Domain Controller'; 5 = 'Primary Domain Controller' }
    [pscustomobject]@{
        ComputerName  = $env:COMPUTERNAME
        Domain        = $cs.Domain
        PartOfDomain  = [bool]$cs.PartOfDomain
        DomainRole    = [int]$cs.DomainRole
        DomainRoleText = $roleName[[int]$cs.DomainRole]
        DetectedRole  = if ([int]$cs.DomainRole -ge 4) { 'DC' } else { 'MS' }
        OSCaption     = $os.Caption
        OSVersion     = $os.Version
        OSBuild       = $os.BuildNumber
        Is64BitOS     = [Environment]::Is64BitOperatingSystem
        IsAdmin       = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
        RunAs         = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        PSVersion     = $PSVersionTable.PSVersion.ToString()
        AuditTime     = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz')
    }
}

function Get-CISRegistryValue {
    <# Reads one registry value READ-ONLY. Returns KeyExists / ValueExists / Value / Kind. #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet('HKLM', 'HKU')][string]$Hive,
        [Parameter(Mandatory)][string]$Key,
        [Parameter(Mandatory)][AllowEmptyString()][string]$Name,
        [string]$UserSid
    )
    $hiveEnum = if ($Hive -eq 'HKLM') { [Microsoft.Win32.RegistryHive]::LocalMachine } else { [Microsoft.Win32.RegistryHive]::Users }
    $subPath = if ($Hive -eq 'HKU') { '{0}\{1}' -f $UserSid, $Key } else { $Key }
    $display = if ($Hive -eq 'HKU') { 'HKU\{0}\{1}' -f $UserSid, $Key } else { 'HKLM\{0}' -f $Key }
    $out = [ordered]@{ Path = $display; Name = $Name; KeyExists = $false; ValueExists = $false; Value = $null; Kind = $null; Error = $null }
    $base = $null; $sub = $null
    try {
        $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey($hiveEnum, [Microsoft.Win32.RegistryView]::Registry64)
        $sub = $base.OpenSubKey($subPath, $false)   # $false = read-only handle
        if ($null -ne $sub) {
            $out.KeyExists = $true
            $match = $sub.GetValueNames() | Where-Object { $_ -ieq $Name } | Select-Object -First 1
            if ($null -ne $match) {
                $out.ValueExists = $true
                $out.Value = $sub.GetValue($match, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                $out.Kind = $sub.GetValueKind($match).ToString()
            }
        }
    }
    catch { $out.Error = $_.Exception.Message }
    finally {
        if ($null -ne $sub) { $sub.Close() }
        if ($null -ne $base) { $base.Close() }
    }
    return [pscustomobject]$out
}

function Get-CISLoadedUserSid {
    <# SIDs of user hives currently loaded under HKEY_USERS (no hive is loaded/unloaded by this tool). #>
    $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::Users, [Microsoft.Win32.RegistryView]::Registry64)
    try { return @($base.GetSubKeyNames() | Where-Object { $_ -match '^S-1-5-21-\d+-\d+-\d+-\d+$' }) }
    finally { $base.Close() }
}

function Get-CISAuditPolicy {
    <# Runs 'auditpol.exe /get /category:* /r' (query only). Returns @{ Map = GUID->object ; Raw = text }. #>
    $raw = & "$env:SystemRoot\System32\auditpol.exe" /get /category:* /r 2>&1
    if ($LASTEXITCODE -ne 0) { throw ('auditpol.exe /get failed (exit {0}): {1}' -f $LASTEXITCODE, ($raw -join ' ')) }
    $lines = @($raw | ForEach-Object { "$_" } | Where-Object { $_.Trim() -ne '' })
    $rows = $lines | ConvertFrom-Csv
    $map = @{}
    foreach ($r in $rows) {
        $guid = ("$($r.'Subcategory GUID')").Trim().ToUpperInvariant()
        if (-not $guid) { continue }
        $setting = ("$($r.'Inclusion Setting')").Trim()
        $flags = $null
        switch -Regex ($setting) {
            '^Success and Failure$' { $flags = 3; break }
            '^Success$' { $flags = 1; break }
            '^Failure$' { $flags = 2; break }
            '^No Auditing$' { $flags = 0; break }
        }
        $map[$guid] = [pscustomobject]@{ Subcategory = $r.Subcategory; Setting = $setting; Flags = $flags }
    }
    return @{ Map = $map; Raw = ($lines -join [Environment]::NewLine) }
}

function Get-CISAccountPolicy {
    <# Password / lockout policy via NetUserModalsGet (levels 0 and 3) and SAM password-properties flags. #>
    $forever = [UInt32]::MaxValue
    $m0 = Get-CISUserModals -Level 0   # min_len, max_age(s), min_age(s), force_logoff(s), history
    $m3 = Get-CISUserModals -Level 3   # lockout_duration(s), observation_window(s), threshold
    $p = [ordered]@{
        MinPasswordLength         = [int]$m0[0]
        MaxPasswordAgeDays        = if ($m0[1] -eq $forever) { 0 } else { [int][math]::Floor($m0[1] / 86400) }
        MinPasswordAgeDays        = [int][math]::Floor($m0[2] / 86400)
        ForceLogoffWhenHourExpire = if ($m0[3] -eq 0) { 1 } else { 0 }
        PasswordHistoryLength     = [int]$m0[4]
        LockoutDurationMinutes    = if ($m3[0] -eq $forever) { 'Forever' } else { [int][math]::Floor($m3[0] / 60) }
        LockoutObservationMinutes = [int][math]::Floor($m3[1] / 60)
        LockoutThreshold          = [int]$m3[2]
        PasswordComplexity        = $null
        ReversibleEncryption      = $null
        AllowAdministratorLockout = $null
        SamError                  = $null
        RawUserModals0            = ($m0 -join ',')
        RawUserModals3            = ($m3 -join ',')
        RawPasswordProperties     = $null
    }
    try {
        $sam = Get-CISSamPasswordProperties
        $flags = [UInt32]$sam.PasswordProperties
        $p.PasswordComplexity = [int](($flags -band 0x1) -ne 0)          # DOMAIN_PASSWORD_COMPLEX
        $p.AllowAdministratorLockout = [int](($flags -band 0x8) -ne 0)   # DOMAIN_LOCKOUT_ADMINS
        $p.ReversibleEncryption = [int](($flags -band 0x10) -ne 0)       # DOMAIN_PASSWORD_STORE_CLEARTEXT
        $p.RawPasswordProperties = ('0x{0:X8}' -f $flags)
    }
    catch { $p.SamError = $_.Exception.Message }
    return [pscustomobject]$p
}

function Get-CISBuiltinAccount {
    <# Built-in Administrator (RID 500) and Guest (RID 501) name + enabled state. #>
    param([Parameter(Mandatory)][string]$DomainSid, [switch]$SkipState)
    $out = @{}
    foreach ($rid in 500, 501) {
        $sid = '{0}-{1}' -f $DomainSid, $rid
        $o = [ordered]@{ Sid = $sid; Name = $null; Disabled = $null; Error = $null }
        try {
            $acct = (New-Object System.Security.Principal.SecurityIdentifier($sid)).Translate([System.Security.Principal.NTAccount]).Value
            $o.Name = ($acct -split '\\')[-1]
            if ($SkipState) { $out[$rid] = [pscustomobject]$o; continue }
            $u = Get-CimInstance -ClassName Win32_UserAccount -Filter ("LocalAccount=True AND SID='{0}'" -f $sid) -ErrorAction Stop | Select-Object -First 1
            if ($null -ne $u) { $o.Disabled = [bool]$u.Disabled }
        }
        catch { $o.Error = $_.Exception.Message }
        $out[$rid] = [pscustomobject]$o
    }
    return $out
}

function Resolve-CISSidName {
    param([Parameter(Mandatory)][string]$Sid)
    try { return (New-Object System.Security.Principal.SecurityIdentifier($Sid)).Translate([System.Security.Principal.NTAccount]).Value }
    catch { return $Sid }
}

Export-ModuleMember -Function Get-CISSystemInfo, Get-CISRegistryValue, Get-CISLoadedUserSid, Get-CISAuditPolicy,
    Get-CISAccountPolicy, Get-CISBuiltinAccount, Resolve-CISSidName
