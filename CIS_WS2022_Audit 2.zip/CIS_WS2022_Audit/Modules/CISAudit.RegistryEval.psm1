#Requires -Version 5.1
# CISAudit-Version: 1.2.0
<#
.SYNOPSIS
    Pure comparison logic for registry-backed CIS recommendations (no system access except the
    read-only Get-CISRegistryValue call made by Invoke-CISRegistryCheck).
#>
Set-StrictMode -Version Latest

function ConvertTo-CISNumber {
    <# Returns [long] or $null. REG_DWORD (Int32) is re-interpreted as unsigned. #>
    param($Value)
    if ($null -eq $Value) { return $null }
    if ($Value -is [int]) { return [long]([BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$Value), 0)) }
    if ($Value -is [long] -or $Value -is [uint32] -or $Value -is [uint64] -or $Value -is [int16]) { return [long]$Value }
    if ($Value -is [string]) {
        $n = 0L
        if ([long]::TryParse($Value.Trim(), [ref]$n)) { return $n }
    }
    return $null
}

function ConvertTo-CISList {
    param($Value)
    if ($null -eq $Value) { return @() }
    if ($Value -is [string[]] -or $Value -is [object[]]) { return @($Value | ForEach-Object { "$_".Trim() } | Where-Object { $_ -ne '' }) }
    $s = "$Value".Trim()
    if ($s -eq '') { return @() }
    return @($s -split '[,\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
}

function Format-CISRegistryData {
    param($Value)
    if ($null -eq $Value) { return '<null>' }
    if ($Value -is [byte[]]) { return 'hex:' + (($Value | ForEach-Object { '{0:X2}' -f $_ }) -join '') }
    if ($Value -is [string[]]) { if ($Value.Count -eq 0) { return '<empty multi-string>' }; return ($Value -join ' | ') }
    $n = ConvertTo-CISNumber -Value $Value
    if ($null -ne $n -and -not ($Value -is [string])) { return ('{0} (0x{0:X})' -f $n) }
    if ("$Value" -eq '') { return '<empty string>' }
    return "$Value"
}

function Test-CISRegistryItem {
    <# Compares one registry read against one expected item. Returns Pass ($true/$false/$null=error) + Reason. #>
    param([Parameter(Mandatory)]$Item, [Parameter(Mandatory)]$Read)
    $absentOk = ($Item.PSObject.Properties.Name -contains 'absentOk') -and [bool]$Item.absentOk
    if ($Read.Error) { return [pscustomobject]@{ Pass = $null; Actual = 'READ ERROR'; Reason = $Read.Error } }
    if ($Item.op -eq 'absent') {
        if ($Read.ValueExists) { return [pscustomobject]@{ Pass = $false; Actual = (Format-CISRegistryData $Read.Value); Reason = 'Value exists but must NOT be present' } }
        return [pscustomobject]@{ Pass = $true; Actual = 'Not present'; Reason = 'Value is not present, as required' }
    }
    if (-not $Read.ValueExists) {
        $what = if ($Read.KeyExists) { 'Value not present' } else { 'Registry key not present' }
        if ($absentOk) { return [pscustomobject]@{ Pass = $true; Actual = "$what (empty)"; Reason = 'Not present is equivalent to the recommended (empty / disabled) state' } }
        return [pscustomobject]@{ Pass = $false; Actual = "$what (Not Configured)"; Reason = 'Setting is not configured; recommended value is not enforced' }
    }
    $v = $Read.Value
    $num = ConvertTo-CISNumber -Value $v
    $str = if ($v -is [string[]]) { $v -join ',' } else { "$v" }
    $pass = $false; $reason = ''
    switch ($Item.op) {
        'eq' {
            $expNum = ConvertTo-CISNumber -Value $Item.value
            if ($null -ne $expNum) { $pass = ($null -ne $num -and $num -eq $expNum) } else { $pass = ($str.Trim() -ieq "$($Item.value)") }
            $reason = "expected = $($Item.value)"
        }
        'streq' {
            $pass = (($str -replace '\s', '') -ieq ("$($Item.value)" -replace '\s', ''))
            $reason = "expected = '$($Item.value)'"
        }
        'in' {
            $pass = ($null -ne $num -and (@($Item.values | ForEach-Object { [long]$_ }) -contains $num))
            $reason = 'expected one of: ' + ($Item.values -join ', ')
        }
        'range' {
            $min = $Item.min; $max = $Item.max
            $pass = ($null -ne $num -and $num -ge [long]$min -and ($null -eq $max -or $num -le [long]$max))
            $reason = if ($null -eq $max) { "expected >= $min" } else { "expected between $min and $max" }
        }
        'nonempty' { $pass = ($str.Trim() -ne ''); $reason = 'expected non-empty organisation-defined value' }
        'empty' { $pass = (@(ConvertTo-CISList -Value $v).Count -eq 0); $reason = 'expected blank / no entries' }
        'subset' {
            $allowed = @($Item.list | ForEach-Object { $_.ToLowerInvariant() })
            $extra = @(ConvertTo-CISList -Value $v | Where-Object { $allowed -notcontains $_.ToLowerInvariant() })
            $pass = ($extra.Count -eq 0)
            $reason = if ($pass) { 'only approved entries present' } else { 'unapproved entries: ' + ($extra -join '; ') }
        }
        'containsAll' {
            $norm = ($str -replace '\s', '').ToLowerInvariant()
            $missing = @($Item.tokens | Where-Object { -not $norm.Contains(($_ -replace '\s', '').ToLowerInvariant()) })
            $pass = ($missing.Count -eq 0)
            $reason = if ($pass) { 'all required flags present' } else { 'missing: ' + ($missing -join ', ') }
        }
        'regex' { $pass = ($str.Trim() -match $Item.pattern); $reason = "expected to match '$($Item.pattern)'" }
        default { return [pscustomobject]@{ Pass = $null; Actual = (Format-CISRegistryData $v); Reason = "Unknown operator '$($Item.op)'" } }
    }
    return [pscustomobject]@{ Pass = [bool]$pass; Actual = (Format-CISRegistryData $v); Reason = $reason }
}

function Get-CISRegQueryCommand {
    param([Parameter(Mandatory)]$Item, [string]$UserSid)
    $path = if ($Item.hive -eq 'HKU') { 'HKU\{0}\{1}' -f $(if ($UserSid) { $UserSid } else { '<USER SID>' }), $Item.key } else { 'HKLM\{0}' -f $Item.key }
    return ('reg query "{0}" /v "{1}"' -f $path, $Item.name)
}

function Invoke-CISRegistryCheck {
    <# Evaluates every registry item of a control. All items must pass (and for HKU items, for every loaded user hive). #>
    param([Parameter(Mandatory)]$Check, [Parameter(Mandatory)]$Context)
    $evidence = New-Object System.Collections.Generic.List[string]
    $actuals = New-Object System.Collections.Generic.List[string]
    $commands = New-Object System.Collections.Generic.List[string]
    $anyFail = $false; $anyError = $false; $evaluated = 0
    $failPresent = $false; $firstNumber = $null
    foreach ($item in @($Check.items)) {
        $targets = @(if ($item.hive -eq 'HKU') { $Context.UserSids } else { '' })
        if ($item.hive -eq 'HKU' -and $targets.Count -eq 0) {
            $evidence.Add('No user registry hives are loaded under HKEY_USERS; per-user setting could not be read.')
            $commands.Add((Get-CISRegQueryCommand -Item $item))
            continue
        }
        foreach ($sid in $targets) {
            $read = Get-CISRegistryValue -Hive $item.hive -Key $item.key -Name $item.name -UserSid $sid
            $t = Test-CISRegistryItem -Item $item -Read $read
            $evaluated++
            if ($null -eq $t.Pass) { $anyError = $true } elseif (-not $t.Pass) { $anyFail = $true; if ($read.ValueExists) { $failPresent = $true } }
            if ($null -eq $firstNumber -and $read.ValueExists) { $firstNumber = ConvertTo-CISNumber -Value $read.Value }
            $status = if ($null -eq $t.Pass) { 'ERROR' } elseif ($t.Pass) { 'PASS' } else { 'FAIL' }
            $kind = if ($read.Kind) { $read.Kind } else { 'n/a' }
            $who = if ($sid) { " [user $(Resolve-CISSidName -Sid $sid)]" } else { '' }
            $evidence.Add(('{0}:{1}{2} | Type={3} | Data={4} | {5} -> {6}' -f $read.Path, $item.name, $who, $kind, $t.Actual, $t.Reason, $status))
            $actuals.Add(('{0}{1} = {2}' -f $item.name, $who, $t.Actual))
            $commands.Add((Get-CISRegQueryCommand -Item $item -UserSid $sid))
        }
    }
    $result = if ($evaluated -eq 0) { 'Manual Review' } elseif ($anyError) { 'Error' } elseif ($anyFail) { 'Non-Compliant' } else { 'Compliant' }
    return [pscustomobject]@{
        Result   = $result
        Actual   = ($actuals -join '; ')
        Evidence = ($evidence -join [Environment]::NewLine)
        Command  = (($commands | Select-Object -Unique) -join [Environment]::NewLine)
        NotConfigured = ($anyFail -and -not $failPresent)   # every failing value is simply absent (policy not set)
        ActualNumber  = $firstNumber
        Extra         = @()
    }
}

Export-ModuleMember -Function Invoke-CISRegistryCheck, Test-CISRegistryItem, ConvertTo-CISNumber, Format-CISRegistryData
