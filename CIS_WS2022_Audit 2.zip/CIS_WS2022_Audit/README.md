# CIS Microsoft Windows Server 2022 Benchmark v5.1.0 – Read-Only Audit Tool

Audits a Windows Server 2022 host against **all 408 recommendations** of the CIS Microsoft Windows Server 2022 Benchmark v5.1.0 (Level 1, Level 2 and Next Generation Windows Security profiles; Domain Controller and Member Server).

## How to run

> **Version 1.2.0 (with severity rating).** Always extract the zip into a **new, empty folder** – extracting over an older copy can leave old files behind. The script checks this and stops with a clear message if files from different versions are mixed. When it starts it prints `CIS audit tool v1.2.0 (with severity rating)`; the Excel Summary sheet shows `ToolVersion 1.2.0`.

1. Copy the whole `CIS_WS2022_Audit` folder to the server (keep the `Modules` and `Data` sub-folders).
2. Open **PowerShell as Administrator** (Windows PowerShell 5.1 or PowerShell 7+).
3. Run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\Invoke-CISWS2022Audit.ps1
# options
.\Invoke-CISWS2022Audit.ps1 -Role MS -Level L1 -OutputPath D:\CIS_Reports
```

| Parameter | Values | Default |
|---|---|---|
| `-Role` | `Auto` (detected from DomainRole), `DC`, `MS` | `Auto` |
| `-Level` | `L1` (Level 1 only), `L2` (L1 + L2), `All` (L1 + L2 + Next Generation) | `All` |
| `-OutputPath` | folder for the reports | `.\Reports` |
| `-NoXlsx` | skip the Excel report | off |

`-ExecutionPolicy Bypass` applies to that one process only; it does not change the machine's policy.

## Output (new, time-stamped files only)

* `CIS_WS2022_v5.1.0_<HOST>_<timestamp>.xlsx` – Summary, By Section and Results sheets (colour-coded)
* `.csv` – the same Results table
* `.html` – browsable report with filter box and expandable benchmark details
* `_Evidence\` – raw data the tool read: `auditpol_all.csv`, `user_rights.txt`, `account_policy.txt`, `net_accounts.txt`, `builtin_accounts.txt`, `loaded_user_hives.txt`, `system_info.txt`

Report columns: Control ID, Section, Title, Profile Level, Applies To, Assessment Status, **Result**, **Severity**, **Finding Severity**, Severity Rationale, Severity Adjustment, Expected Value, Actual Value, Evidence, Evidence Command, Description, Rationale, Impact, Audit Procedure, Remediation, Default Value, References, CIS Controls Mapping, Hostname, Audit Timestamp.

## Result values

| Result | Meaning |
|---|---|
| Compliant | The value read from the host meets the recommendation |
| Non-Compliant | The value differs, or the setting is not configured (Not Defined) |
| Not Applicable | Recommendation is for the other role (DC vs MS) or for a profile you did not select |
| Manual Review | Per-user (HKU) setting and no user hive is loaded |
| Error | Data could not be read (usually: not run as Administrator) – see Evidence |

## Severity (Critical / High / Medium / Low / Informational)

| Severity | Meaning |
|---|---|
| Critical | Directly exploitable for full compromise (SYSTEM / domain / clear-text credentials) with little effort and no compensating control |
| High | Weakens a primary security boundary (authentication, credential protection, network exposure); commonly abused in real attacks |
| Medium | Weakens defence-in-depth, detection or hardening; needs another weakness or a privileged foothold |
| Low | Minor hardening gap, limited impact, or a secure state that is not centrally enforced |
| Informational | Privacy / usability / compliance-only, or no security effect in this host's context |

* **Severity** – inherent (base) risk of each of the 408 recommendations, with a one-line **Severity Rationale**.
* **Finding Severity** – risk of *this host's* finding. Starting from the base severity it is adjusted automatically and every change is explained in **Severity Adjustment**:
  1. *Actual value* – e.g. LAN Manager level 0–2 → Critical; Point-and-Print "no warning" → Critical; UAC "elevate without prompting" → High; AlwaysInstallElevated set only in HKLM (HKCU also required) → High.
  2. *Not configured but Windows default is already secure* → Low (base High/Critical) or Informational.
  3. *User rights* – one level up if a broad group (Everyone, Users, Authenticated Users, Domain Users, Guests, Anonymous) holds the right; one level down if only service/virtual accounts were added.
  4. *Compensating controls* – e.g. SMB encryption required ⇢ SMB signing; NLA ⇢ RDP security layer; LAPS + UAC remote restrictions ⇢ local-admin network logon; RunAsPPL ⇢ Credential Guard; legacy Microsoft LAPS ⇢ Windows LAPS; password length ≥ 14/15 ⇢ complexity / LM hash; firewall on locally ⇢ firewall not enforced by GPO.
  5. *Feature not in use* – Print Spooler / RDP / WinRM disabled, SMBv1 not installed, Guest or built-in Administrator disabled, lockout disabled (reported once under 1.2.2).
* Context facts are read with the same read-only registry reader and saved to `_Evidence\severity_context_facts.txt`. A fact that cannot be read stays *unknown* and never lowers a severity. Error / Manual Review rows keep the base severity until verified.
* The Excel report has a **Findings by Severity** sheet (open findings sorted Critical → Informational) and a **Severity Scale** sheet.

## Read-only guarantee

| Data | How it is read |
|---|---|
| Registry (312 checks) | `RegistryKey.OpenSubKey(path, writable = $false)` – 64-bit view |
| User Rights Assignment (48) | `LsaOpenPolicy` (VIEW_LOCAL_INFORMATION + LOOKUP_NAMES) → `LsaEnumerateAccountsWithUserRight` |
| Password / lockout policy (11) | `NetUserModalsGet` + `SamQueryInformationDomain` (DOMAIN_READ_PASSWORD_PARAMETERS) |
| Advanced audit policy (34) | `auditpol.exe /get /category:* /r` |
| Built-in accounts (3) | `Get-CimInstance Win32_UserAccount` + SID translation |
| Severity context facts | Same read-only registry reader (service start types, firewall, LAPS, RDP, SMB). `DefaultPassword` is only tested for existence – its value is never read into the report |

* No `secedit /export`, no temporary files, no `Add-Type` compilation – P/Invoke signatures are defined in memory.
* No registry hive is loaded or unloaded; per-user (section 19) settings are read from hives already loaded under `HKEY_USERS` (the auditor's own profile is always loaded).
* The only writes are the new report files in `-OutputPath`: files are opened with `FileMode.CreateNew` / `Export-Csv -NoClobber`, so an existing file is never overwritten, and the tool refuses to write into `C:\Windows`, `Program Files`, `Program Files (x86)` or `ProgramData`.
* `Add-Type` is used only as `Add-Type -AssemblyName System.IO.Compression` (loads a built-in .NET library to build the .xlsx; nothing is compiled).

### Verify it yourself

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\Test-CISAuditSafety.ps1
```

This static checker does not run the audit. It parses every script file and fails if it finds any command that is not on a read-only allow-list, `auditpol` / `net` called with anything other than query arguments, a registry key opened writable, any registry / file / LSA / SAM / NetAPI / service modification API, or a native access mask other than the read-only ones.

### Expected side effects (not changes made by the tool)

* Windows itself may log the audit activity: PowerShell script-block / transcription logging (if enabled), and Security-log events for privilege use or account / group enumeration (e.g. 4673, 4798, 4799) if those audit subcategories are on.
* `-ExecutionPolicy Bypass` affects only the PowerShell process that runs the tool.

## Notes for auditors

* Password / lockout values reflect the effective policy of the account domain (domain policy on DCs, local SAM on member servers). Fine-Grained Password Policies (PSOs) are not evaluated.
* "Not configured" is reported as Non-Compliant except where CIS states the value must be absent/blank (2.3.5.2, 2.3.10.6/7/8/9/12, 18.9.19.5) or where absence equals the recommended state (2.3.10.1).
* Audit-policy evaluation reads the English `auditpol` output; on a non-English OS those checks report Error with the raw text so you can verify manually.
* 2.3.10.1 (Allow anonymous SID/Name translation) is read from `HKLM\SYSTEM\CurrentControlSet\Control\Lsa\TurnOffAnonymousBlock` (absent/0 = Disabled).
